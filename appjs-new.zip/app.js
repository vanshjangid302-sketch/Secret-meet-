/* Secret Meet — app.js (fresh replacement)
   Uses existing Supabase project. Set the anon key below before publishing.
*/
(() => {
  "use strict";

  const SUPABASE_URL = "https://jcgkforrpinbwvosjvwb.supabase.co";
  const SUPABASE_ANON_KEY = window.SECRET_MEET_ANON_KEY || "PASTE_YOUR_SUPABASE_ANON_KEY_HERE";

  const $ = (selector) => document.querySelector(selector);
  const $$ = (selector) => Array.from(document.querySelectorAll(selector));
  const say = (msg, type = "info") => {
    const box = $("#notice") || $("#message") || $("#status-message");
    if (box) {
      box.textContent = msg;
      box.dataset.type = type;
      box.style.display = "block";
    } else {
      console.log(`[Secret Meet ${type}] ${msg}`);
    }
  };

  if (!window.supabase) {
    say("Supabase library not found. Add the Supabase JS CDN script in index.html.", "error");
    return;
  }
  if (!SUPABASE_ANON_KEY || SUPABASE_ANON_KEY.includes("PASTE_YOUR")) {
    say("Supabase anon key is missing. Add it in app.js before using the site.", "error");
  }

  const db = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
  window.secretMeet = { db };

  let currentUser = null;
  let myProfile = null;
  let activeMatchId = null;

  // Supports common IDs and form names without requiring a specific page layout.
  const pick = (...selectors) => selectors.map(s => $(s)).find(Boolean) || null;
  const field = (form, names) => {
    for (const n of names) {
      const el = form?.querySelector(`[name="${n}"], #${n}`);
      if (el) return el.value?.trim() ?? "";
    }
    return "";
  };

  async function loadSession() {
    const { data, error } = await db.auth.getSession();
    if (error) throw error;
    currentUser = data.session?.user || null;
    window.secretMeet.user = currentUser;
    return currentUser;
  }

  async function getProfile(userId = currentUser?.id) {
    if (!userId) return null;
    const { data, error } = await db.from("profiles").select("*").eq("id", userId).maybeSingle();
    if (error) throw error;
    return data;
  }

  async function ensureProfile(user) {
    const profile = await getProfile(user.id);
    if (profile) return profile;
    const displayName = user.user_metadata?.name || user.user_metadata?.full_name ||
      user.email?.split("@")[0] || "Member";
    const { data, error } = await db.from("profiles")
      .insert({ id: user.id, name: displayName })
      .select("*").maybeSingle();
    if (error) {
      // Profile schema may use a different display-name field; don't block login.
      console.warn("Profile auto-create skipped:", error.message);
      return null;
    }
    return data;
  }

  async function signUp(email, password, name = "") {
    const { data, error } = await db.auth.signUp({
      email, password, options: { data: { name, full_name: name } }
    });
    if (error) throw error;
    if (data.user && data.session) {
      currentUser = data.user;
      myProfile = await ensureProfile(data.user);
    }
    say(data.session ? "Account created and logged in." : "Account created. Check your email to confirm.", "success");
    return data;
  }

  async function signIn(email, password) {
    const { data, error } = await db.auth.signInWithPassword({ email, password });
    if (error) throw error;
    currentUser = data.user;
    myProfile = await ensureProfile(data.user);
    say("Login successful.", "success");
    await refreshUI();
    return data;
  }

  async function signOut() {
    const { error } = await db.auth.signOut();
    if (error) throw error;
    currentUser = null;
    myProfile = null;
    activeMatchId = null;
    say("You have logged out.", "success");
    await refreshUI();
  }

  async function updateProfile(updates) {
    if (!currentUser) throw new Error("Please log in first.");
    const { data, error } = await db.from("profiles")
      .update(updates).eq("id", currentUser.id).select("*").maybeSingle();
    if (error) throw error;
    myProfile = data;
    say("Profile saved.", "success");
    return data;
  }

  async function getDiscoverProfiles() {
    if (!currentUser) return [];
    const { data, error } = await db.from("profiles").select("*").neq("id", currentUser.id).limit(100);
    if (error) throw error;
    return data || [];
  }

  async function likeProfile(targetUserId) {
    if (!currentUser) throw new Error("Login to like profiles.");
    if (!targetUserId || targetUserId === currentUser.id) return;
    const { error } = await db.from("likes").insert({
      liker_id: currentUser.id,
      liked_id: targetUserId
    });
    if (error && !/duplicate|unique/i.test(error.message)) throw error;

    // Check reciprocal like; if present, create a match. Assumes matches table stores user IDs.
    const { data: reciprocal, error: reciprocalErr } = await db.from("likes")
      .select("*").eq("liker_id", targetUserId).eq("liked_id", currentUser.id).maybeSingle();
    if (reciprocalErr) throw reciprocalErr;
    if (reciprocal) {
      const { error: matchErr } = await db.from("matches").insert({
        user1_id: currentUser.id,
        user2_id: targetUserId
      });
      if (matchErr && !/duplicate|unique/i.test(matchErr.message)) throw matchErr;
      say("It's a match!", "success");
      return { matched: true };
    }
    say("Like sent.", "success");
    return { matched: false };
  }

  async function getMatches() {
    if (!currentUser) return [];
    const { data, error } = await db.from("matches").select("*")
      .or(`user1_id.eq.${currentUser.id},user2_id.eq.${currentUser.id}`);
    if (error) throw error;
    return data || [];
  }

  async function getMessages(matchId) {
    if (!currentUser || !matchId) return [];
    const { data, error } = await db.from("messages").select("*")
      .eq("match_id", matchId).order("created_at", { ascending: true });
    if (error) throw error;
    return data || [];
  }

  async function sendMessage(matchId, body) {
    if (!currentUser) throw new Error("Please log in first.");
    const clean = String(body || "").trim();
    if (!clean) return;
    const { data, error } = await db.from("messages").insert({
      match_id: matchId,
      sender_id: currentUser.id,
      body: clean
    }).select("*").maybeSingle();
    if (error) throw error;
    say("Message sent.", "success");
    return data;
  }

  async function blockUser(userId) {
    if (!currentUser) throw new Error("Please log in first.");
    const { error } = await db.from("blocks").insert({
      blocker_id: currentUser.id,
      blocked_id: userId
    });
    if (error && !/duplicate|unique/i.test(error.message)) throw error;
    say("User blocked.", "success");
  }

  async function reportUser(userId, reason = "") {
    if (!currentUser) throw new Error("Please log in first.");
    const { error } = await db.from("reports").insert({
      reporter_id: currentUser.id,
      reported_id: userId,
      reason
    });
    if (error) throw error;
    say("Report submitted.", "success");
  }

  async function isAdmin() {
    if (!currentUser) return false;
    const profile = myProfile || await getProfile();
    return profile?.role === "admin" && profile?.status !== "blocked" && profile?.status !== "suspended";
  }

  async function adminListProfiles() {
    if (!(await isAdmin())) throw new Error("Admin access required.");
    const { data, error } = await db.from("profiles").select("*").order("created_at", { ascending: false });
    if (error) throw error;
    return data || [];
  }

  async function adminSetUserStatus(userId, status) {
    if (!(await isAdmin())) throw new Error("Admin access required.");
    const { error } = await db.from("profiles").update({ status }).eq("id", userId);
    if (error) throw error;
    say("User status updated.", "success");
  }

  function bindForms() {
    const loginForm = pick("#login-form", "#loginForm", 'form[data-form="login"]');
    if (loginForm && !loginForm.dataset.smBound) {
      loginForm.dataset.smBound = "1";
      loginForm.addEventListener("submit", async (e) => {
        e.preventDefault();
        try {
          await signIn(field(loginForm, ["email", "login-email"]), field(loginForm, ["password", "login-password"]));
        } catch (err) { say(err.message, "error"); }
      });
    }

    const signupForm = pick("#signup-form", "#register-form", "#signupForm", 'form[data-form="signup"]');
    if (signupForm && !signupForm.dataset.smBound) {
      signupForm.dataset.smBound = "1";
      signupForm.addEventListener("submit", async (e) => {
        e.preventDefault();
        try {
          await signUp(
            field(signupForm, ["email", "signup-email"]),
            field(signupForm, ["password", "signup-password"]),
            field(signupForm, ["name", "full_name", "username"])
          );
        } catch (err) { say(err.message, "error"); }
      });
    }

    const logoutBtn = pick("#logout", "#logout-btn", "[data-action='logout']");
    if (logoutBtn && !logoutBtn.dataset.smBound) {
      logoutBtn.dataset.smBound = "1";
      logoutBtn.addEventListener("click", (e) => { e.preventDefault(); signOut().catch(err => say(err.message, "error")); });
    }

    const profileForm = pick("#profile-form", "#edit-profile-form", 'form[data-form="profile"]');
    if (profileForm && !profileForm.dataset.smBound) {
      profileForm.dataset.smBound = "1";
      profileForm.addEventListener("submit", async (e) => {
        e.preventDefault();
        try {
          const updates = {};
          ["name", "username", "bio", "age", "gender", "city", "photo_url"].forEach((key) => {
            const el = profileForm.querySelector(`[name="${key}"]`);
            if (el && el.value.trim() !== "") updates[key] = key === "age" ? Number(el.value) : el.value.trim();
          });
          await updateProfile(updates);
        } catch (err) { say(err.message, "error"); }
      });
    }

    $$("[data-like-user]").forEach(btn => {
      if (btn.dataset.smBound) return;
      btn.dataset.smBound = "1";
      btn.addEventListener("click", () => likeProfile(btn.dataset.likeUser).catch(err => say(err.message, "error")));
    });

    $$("[data-block-user]").forEach(btn => {
      if (btn.dataset.smBound) return;
      btn.dataset.smBound = "1";
      btn.addEventListener("click", () => blockUser(btn.dataset.blockUser).catch(err => say(err.message, "error")));
    });

    $$("[data-report-user]").forEach(btn => {
      if (btn.dataset.smBound) return;
      btn.dataset.smBound = "1";
      btn.addEventListener("click", () => reportUser(btn.dataset.reportUser, btn.dataset.reason || "").catch(err => say(err.message, "error")));
    });

    const chatForm = pick("#chat-form", "#message-form", 'form[data-form="chat"]');
    if (chatForm && !chatForm.dataset.smBound) {
      chatForm.dataset.smBound = "1";
      chatForm.addEventListener("submit", async (e) => {
        e.preventDefault();
        const textEl = chatForm.querySelector('[name="body"], [name="message"], #message-input');
        const matchId = chatForm.dataset.matchId || activeMatchId;
        try {
          await sendMessage(matchId, textEl?.value || "");
          if (textEl) textEl.value = "";
          if (matchId) await renderMessages(matchId);
        } catch (err) { say(err.message, "error"); }
      });
    }
  }

  async function renderMessages(matchId, container = $("#messages")) {
    if (!container) return;
    const rows = await getMessages(matchId);
    container.innerHTML = "";
    rows.forEach(m => {
      const item = document.createElement("div");
      item.className = "message" + (m.sender_id === currentUser?.id ? " mine" : "");
      item.textContent = m.body || "";
      container.appendChild(item);
    });
    container.scrollTop = container.scrollHeight;
  }

  async function refreshUI() {
    document.body.dataset.loggedIn = currentUser ? "true" : "false";
    $$(".logged-in").forEach(el => el.style.display = currentUser ? "" : "none");
    $$(".logged-out").forEach(el => el.style.display = currentUser ? "none" : "");
    $$(".admin-only").forEach(el => el.style.display = (myProfile?.role === "admin" && myProfile?.status !== "blocked" && myProfile?.status !== "suspended") ? "" : "none");
    const userLabel = pick("#current-user", "#user-name");
    if (userLabel) userLabel.textContent = myProfile?.name || myProfile?.username || currentUser?.email || "";
  }

  async function start() {
    try {
      await loadSession();
      if (currentUser) myProfile = await getProfile();
      bindForms();
      await refreshUI();
    } catch (err) {
      console.error("Secret Meet startup error:", err);
      say(err.message || "App startup error.", "error");
    }
  }

  // Public helpers for page buttons / inline handlers.
  window.secretMeet = {
    db, signUp, signIn, signOut, getProfile, updateProfile,
    getDiscoverProfiles, likeProfile, getMatches, getMessages, sendMessage,
    renderMessages, blockUser, reportUser, isAdmin, adminListProfiles,
    adminSetUserStatus, setActiveMatch: (id) => { activeMatchId = id; },
    get user() { return currentUser; },
    get profile() { return myProfile; }
  };

  document.addEventListener("DOMContentLoaded", start);
  if (document.readyState !== "loading") start();
})();
