# Secret Meet MVP

Starter frontend for a Supabase-backed 18+ dating app. This build is intentionally a modest MVP; it must be reviewed and tested against the existing database before public launch.


## Local setup
1. Install Node.js LTS.
2. Copy `.env.example` to `.env` and enter the Supabase Project URL and **anon/publishable** key (never service-role key).
3. Run `npm install`, then `npm run dev`.

## Free deployment (Netlify)
1. Upload this folder to a new GitHub repository (or push using Git).
2. In Netlify, Add new site → Import an existing project → select repository.
3. Build command `npm run build`, publish directory `dist`.
4. Add environment variables `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` in Site configuration → Environment variables.
5. Deploy, then add the deployed URL to Supabase Auth → URL Configuration → Site URL and Redirect URLs.

## Current MVP caveats
- Profile reads assume a `profiles` table with `id`, `display_name`, `age`, `city`, `bio`, `photo_url`, and optionally `role` or `is_admin`.
- Like insert assumes `likes(liker_id, liked_id)`.
- Profiles display in the discovery list. The current demo fallback profile cards are illustrative and not real users; remove them before production.
- Messaging, real match detection, report/block workflows, image upload storage, admin moderation and age/consent flows need database schema verification and completion before public use.
- Confirm all Supabase tables have correct RLS enabled. Never expose service-role credentials in frontend or commit them.
- A free tier may pause or have limits. Check the provider's current free-tier terms before public launch.
